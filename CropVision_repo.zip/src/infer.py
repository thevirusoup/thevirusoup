# Inference example: load model and run on a small tile or sample
import torch
import numpy as np
from src.models.tempcnn import TempCNN

def load_model(path, input_features, num_classes):
    model = TempCNN(input_features, num_classes)
    state = torch.load(path, map_location='cpu')
    model.load_state_dict(state)
    model.eval()
    return model

def predict_sample(model, X):
    # X: numpy (T,F) or (1,T,F)
    if X.ndim == 2:
        X = X[None,...]
    X = torch.tensor(X, dtype=torch.float32)
    with torch.no_grad():
        logits = model(X)
        probs = torch.softmax(logits, dim=1).numpy()
        preds = probs.argmax(axis=1)
    return preds, probs

if __name__ == '__main__':
    print('This is a demo inference script. Replace model path and inputs as needed.')
