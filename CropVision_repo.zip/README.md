# CropVision

CropVision is an academic research starter repository for crop identification using satellite imagery (Sentinel-2 / Landsat) and temporal deep learning models (TempCNN / Transformer).

## Contents
- `src/` - source code for data ingestion, preprocessing, feature extraction, modeling, and inference.
- `notebooks/` - quick demos and experiments (Colab-ready).
- `requirements.txt` - Python packages to install.
- `LICENSE` - MIT License.

## Quickstart (local / Colab)
1. Create a Python environment and install requirements:
   ```bash
   pip install -r requirements.txt
   ```
2. If using Google Earth Engine (recommended for ingestion), authenticate and export composites or use STAC to download tiles.
3. Run a quick demo (EuroSAT) notebook in `notebooks/` or train a TempCNN:
   ```bash
   python src/train.py --config config/example.yaml
   ```

## Notes
- This repository is a *starter template* and contains code skeletons and examples. For production or full experiments, adapt data ingestion to your access method (GEE, AWS, Sentinel Hub, or direct downloads).
- See `src/README_components.md` for details about each module.
