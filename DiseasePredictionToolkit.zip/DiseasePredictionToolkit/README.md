# Disease Prediction Toolkit

Predict diseases from healthcare data using multiple machine learning models.

## About This Project
This toolkit trains and evaluates Logistic Regression, Decision Tree, and Random Forest models on a real healthcare dataset (Breast Cancer Wisconsin). It provides preprocessing, training, evaluation, visualization, and simple inference scripts, plus a 5‑slide presentation.

## Quickstart (Local / Colab)
- Python 3.9+
- `pip install -r requirements.txt`



### Try in Google Colab
- Upload this repo (zipped) to your Drive or clone your GitHub repo.
- `pip install -r requirements.txt`
- Open `notebooks/disease_prediction_toolkit_colab.ipynb` (included) and run the cells.

## Repository Structure
```
DiseasePredictionToolkit/
├── data/
│   ├── raw/  # original data (breast_cancer_wisconsin.csv)
│   └── processed/  # numpy arrays + splits
├── docs/   # README, presentation, demo instructions
├── models/ # saved models + preprocessor
├── notebooks/ # Colab-ready notebook
├── outputs/ # evaluation figures + metrics + predictions
├── scripts/ # CLI scripts for preprocess/train/evaluate/predict
└── tests/   # simple tests for inference
```

## Models Included
- Logistic Regression
- Decision Tree
- Random Forest

## Evaluation Metrics
See `outputs/model_metrics.csv` and confusion matrix + ROC curve images in `outputs/`.

## Make Predictions
Supply a CSV with the same columns as `data/raw/breast_cancer_wisconsin.csv` (excluding the `label` column). Then:
```bash
python scripts/predict.py --model random_forest --input_path path/to/your.csv --output_path outputs/preds.csv
```

## License
MIT
