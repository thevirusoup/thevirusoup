Module descriptions:
- data/ingest_gee.py: Example of fetching composites using Google Earth Engine (requires GEE auth).
- data/make_composites.py: Local utilities to build composites from downloaded tiles.
- features/indices.py: Functions to compute NDVI, EVI, NDWI, NDRE.
- models/tempcnn.py: Lightweight TempCNN implementation in PyTorch.
- train.py: Training loop using PyTorch Lightning.
- infer.py: Tile-based inference that outputs GeoTIFF (COG) per scene.
