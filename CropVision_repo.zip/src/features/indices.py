import numpy as np

def ndvi(nir, red, eps=1e-6):
    # nir, red: numpy arrays
    return (nir - red) / (nir + red + eps)

def ndwi(nir, swir, eps=1e-6):
    return (nir - swir) / (nir + swir + eps)

def evi(nir, red, blue, G=2.5, C1=6.0, C2=7.5, L=1.0, eps=1e-6):
    # EVI formula
    return G * (nir - red) / (nir + C1*red - C2*blue + L + eps)

def ndre(nir, rededge, eps=1e-6):
    return (nir - rededge) / (nir + rededge + eps)
