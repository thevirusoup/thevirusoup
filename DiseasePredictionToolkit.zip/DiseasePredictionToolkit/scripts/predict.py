import argparse, pandas as pd, numpy as np
from pathlib import Path
from joblib import load

def main(args):
    model_name = args.model
    input_path = Path(args.input_path)
    output_path = Path(args.output_path)

    df = pd.read_csv(input_path)
    # Drop label if present
    df_features = df.drop(columns=["label"], errors="ignore")

    preprocessor = load("models/preprocessor.joblib")
    X_proc = preprocessor.transform(df_features)

    clf = load(f"models/{model_name}.joblib")
    preds = clf.predict(X_proc)
    try:
        probs = clf.predict_proba(X_proc)[:, 1]
    except Exception:
        probs = None

    out = df.copy()
    out["prediction"] = preds
    if probs is not None:
        out["probability"] = probs

    output_path.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(output_path, index=False)
    print(f"Saved predictions to {output_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, default="random_forest", choices=["log_reg", "decision_tree", "random_forest"])
    parser.add_argument("--input_path", type=str, required=True)
    parser.add_argument("--output_path", type=str, default="outputs/predictions.csv")
    args = parser.parse_args()
    main(args)
