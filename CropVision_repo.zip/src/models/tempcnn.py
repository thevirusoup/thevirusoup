import torch
import torch.nn as nn

class TempConvBlock(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, padding=1):
        super().__init__()
        self.conv = nn.Conv1d(in_channels, out_channels, kernel_size, padding=padding)
        self.bn = nn.BatchNorm1d(out_channels)
        self.act = nn.ReLU()
    def forward(self, x):
        # x: (batch, channels, timesteps)
        return self.act(self.bn(self.conv(x)))

class TempCNN(nn.Module):
    def __init__(self, input_features, num_classes, channels=[64,128], kernel=3):
        super().__init__()
        layers = []
        in_ch = input_features
        for ch in channels:
            layers.append(TempConvBlock(in_ch, ch, kernel_size=kernel))
            in_ch = ch
        self.tconv = nn.Sequential(*layers)
        self.pool = nn.AdaptiveAvgPool1d(1)
        self.fc = nn.Linear(in_ch, num_classes)
    def forward(self, x):
        # x: (batch, timesteps, features)
        # transpose -> (batch, features, timesteps)
        x = x.permute(0,2,1)
        x = self.tconv(x)
        x = self.pool(x).squeeze(-1)
        out = self.fc(x)
        return out
