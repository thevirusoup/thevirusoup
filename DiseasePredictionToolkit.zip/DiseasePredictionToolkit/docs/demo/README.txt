This demo shows loading the dataset, training a model, and predicting.

1) Train: python scripts/train.py --model random_forest

2) Evaluate: python scripts/evaluate.py --model random_forest

3) Predict: python scripts/predict.py --model random_forest --input_path data/raw/breast_cancer_wisconsin.csv --output_path outputs/predictions.csv

Alternative: generate a 30-second MP4 automatically:
python scripts/make_demo_video.py --output docs/demo/demo.mp4 --fps 3
