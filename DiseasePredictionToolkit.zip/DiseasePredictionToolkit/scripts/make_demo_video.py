import io
import argparse
import matplotlib.pyplot as plt
import imageio.v3 as iio

def build_frames():
    frames = []
    for msg in [
        "Disease Prediction Toolkit",
        "Loading Dataset...",
        "Preprocessing (Impute + Scale)...",
        "Training Random Forest...",
        "Evaluating (F1 / ROC-AUC)...",
        "Predicting on New Data...",
        "Done!"
    ]:
        fig = plt.figure(figsize=(6,4))
        plt.axis("off")
        plt.text(0.5, 0.5, msg, ha="center", va="center", fontsize=24)
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=120, bbox_inches="tight")
        plt.close(fig)
        buf.seek(0)
        frames.append(buf.getvalue())
    return frames

def main(args):
    output = args.output
    fps = args.fps
    frames = build_frames()
    imgs = []
    for _ in range(15):  # ~7*15 frames at fps 3 ≈ 35 sec
        imgs.extend(frames)
    iio.imwrite(output, [iio.imread(f) for f in imgs], fps=fps)
    print(f"Saved demo video to {output}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=str, default="docs/demo/demo.mp4")
    parser.add_argument("--fps", type=int, default=3)
    args = parser.parse_args()
    main(args)
