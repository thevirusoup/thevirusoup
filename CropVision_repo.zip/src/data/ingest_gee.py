# Example: Google Earth Engine ingestion helper
# NOTE: This script is a template. Run in Colab or environment with GEE authenticated.
import ee
import os
import json
from datetime import datetime

def init_gee():
    try:
        ee.Initialize()
    except Exception as e:
        print('Initialize Earth Engine (run ee.Authenticate() first in interactive env).', e)
        raise

def export_monthly_composites(aoi, start_year, end_year, out_folder, bands=None):
    '''
    aoi: ee.Geometry (polygon)
    start_year, end_year: ints
    out_folder: local folder to save (requires an export routine)
    '''
    init_gee()
    if bands is None:
        bands = ['B2','B3','B4','B8','B11','B12']  # Sentinel-2 common bands
    for year in range(start_year, end_year+1):
        for month in range(1,13):
            start = datetime(year, month, 1)
            # This is a template for creating monthly median composites
            print(f'Preparing composite for {start.year}-{start.month:02d}')
            # Implementation depends on your export or download method.

if __name__ == '__main__':
    print('This is a template for Google Earth Engine ingestion. Use from notebook.')
