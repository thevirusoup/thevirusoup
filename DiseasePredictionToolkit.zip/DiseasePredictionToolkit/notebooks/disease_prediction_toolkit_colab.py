# Colab Quickstart (text version)
# 1) Upload repo and run:
# !pip install -r requirements.txt
# 2) Preprocess (optional – already saved here):
# !python scripts/preprocess.py --input_path data/raw/breast_cancer_wisconsin.csv --output_dir data/processed
# 3) Train:
# !python scripts/train.py --model random_forest
# 4) Evaluate:
# !python scripts/evaluate.py --model random_forest
# 5) Predict on the same dataset (for demo):
# !python scripts/predict.py --model random_forest --input_path data/raw/breast_cancer_wisconsin.csv --output_path outputs/predictions.csv
