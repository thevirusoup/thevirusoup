import argparse, pandas as pd, numpy as np
from pathlib import Path
from joblib import dump
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline

def build_preprocessor(X):
    num_cols = X.select_dtypes(include=[np.number]).columns.tolist()
    cat_cols = X.select_dtypes(exclude=[np.number]).columns.tolist()

    numeric_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])

    categorical_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore"))
    ])

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", numeric_transformer, num_cols),
            ("cat", categorical_transformer, cat_cols),
        ]
    )
    return preprocessor

def main(args):
    input_path = Path(args.input_path)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(input_path)
    y = df["label"] if "label" in df.columns else None
    X = df.drop(columns=["label"], errors="ignore")

    preprocessor = build_preprocessor(X)
    preprocessor.fit(X)
    X_proc = preprocessor.transform(X)
    np.save(output_dir / "X_full.npy", X_proc)
    if y is not None:
        np.save(output_dir / "y_full.npy", y.to_numpy())
    dump(preprocessor, output_dir / "preprocessor.joblib")
    print("Preprocessing complete. Saved arrays and preprocessor.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_path", type=str, required=True)
    parser.add_argument("--output_dir", type=str, default="data/processed")
    args = parser.parse_args()
    main(args)
