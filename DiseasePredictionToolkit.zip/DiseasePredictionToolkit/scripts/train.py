import argparse, numpy as np, pandas as pd
from pathlib import Path
from joblib import dump, load
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score

def main(args):
    data_path = Path("data/raw/breast_cancer_wisconsin.csv")
    df = pd.read_csv(data_path)
    y = df["label"]
    X = df.drop(columns=["label"])

    preprocessor = load("models/preprocessor.joblib")
    X_proc = preprocessor.transform(X)

    X_train, X_test, y_train, y_test = train_test_split(
        X_proc, y, test_size=0.2, random_state=42, stratify=y
    )

    models = {
        "log_reg": LogisticRegression(max_iter=2000, class_weight="balanced", random_state=42),
        "decision_tree": DecisionTreeClassifier(class_weight="balanced", random_state=42),
        "random_forest": RandomForestClassifier(n_estimators=400, class_weight="balanced", random_state=42),
    }

    clf = models[args.model]
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    f1 = f1_score(y_test, y_pred)
    print(f"Trained {args.model}. Test F1: {f1:.3f}")
    dump(clf, f"models/{args.model}.joblib")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, default="random_forest", choices=["log_reg", "decision_tree", "random_forest"])
    args = parser.parse_args()
    main(args)
