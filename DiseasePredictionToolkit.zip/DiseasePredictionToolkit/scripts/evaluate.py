import argparse, numpy as np, pandas as pd
from pathlib import Path
from joblib import load
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score,
    roc_curve, confusion_matrix, classification_report
)
import matplotlib.pyplot as plt

def main(args):
    df = pd.read_csv("data/raw/breast_cancer_wisconsin.csv")
    y = df["label"]
    X = df.drop(columns=["label"])

    preprocessor = load("models/preprocessor.joblib")
    X_proc = preprocessor.transform(X)
    X_train, X_test, y_train, y_test = train_test_split(
        X_proc, y, test_size=0.2, random_state=42, stratify=y
    )

    clf = load(f"models/{args.model}.joblib")
    y_pred = clf.predict(X_test)
    try:
        y_proba = clf.predict_proba(X_test)[:, 1]
    except Exception:
        y_proba = None

    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred)
    rec = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    roc_auc = roc_auc_score(y_test, y_proba) if y_proba is not None else float("nan")

    metrics = {
        "model": args.model,
        "accuracy": acc, "precision": prec, "recall": rec, "f1_score": f1, "roc_auc": roc_auc
    }
    print(metrics)

    # Confusion matrix
    cm = confusion_matrix(y_test, y_pred)
    plt.figure()
    plt.imshow(cm, interpolation="nearest")
    plt.title(f"Confusion Matrix: {args.model}")
    plt.xlabel("Predicted label")
    plt.ylabel("True label")
    for (i, j), val in np.ndenumerate(cm):
        plt.text(j, i, int(val), ha="center", va="center")
    plt.tight_layout()
    plt.savefig(f"outputs/confusion_matrix_{args.model}.png")

    # ROC
    if y_proba is not None:
        from sklearn.metrics import roc_curve
        fpr, tpr, _ = roc_curve(y_test, y_proba)
        plt.figure()
        plt.plot(fpr, tpr, label=f"AUC={roc_auc:.3f}")
        plt.plot([0,1], [0,1], linestyle="--")
        plt.xlabel("FPR")
        plt.ylabel("TPR")
        plt.legend(loc="lower right")
        plt.tight_layout()
        plt.savefig(f"outputs/roc_curve_{args.model}.png")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, default="random_forest", choices=["log_reg", "decision_tree", "random_forest"])
    args = parser.parse_args()
    main(args)
