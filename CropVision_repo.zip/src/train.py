# Training script (example) using PyTorch Lightning
import argparse
import yaml
import torch
from torch.utils.data import Dataset, DataLoader
import pytorch_lightning as pl
import torch.nn as nn
import torch.optim as optim
from src.models.tempcnn import TempCNN

class TimeSeriesDataset(Dataset):
    def __init__(self, X, y):
        # X: numpy array (N, T, F)
        self.X = X
        self.y = y
    def __len__(self):
        return len(self.X)
    def __getitem__(self, idx):
        import numpy as np
        x = self.X[idx].astype('float32')
        y = int(self.y[idx])
        return x, y

class LitModel(pl.LightningModule):
    def __init__(self, hparams):
        super().__init__()
        self.save_hyperparameters(hparams)
        self.model = TempCNN(hparams['n_features'], hparams['n_classes'])
        self.criterion = nn.CrossEntropyLoss()
    def forward(self, x):
        return self.model(x)
    def training_step(self, batch, batch_idx):
        x,y = batch
        logits = self(x)
        loss = self.criterion(logits, y)
        acc = (logits.argmax(dim=1) == y).float().mean()
        self.log('train_loss', loss)
        self.log('train_acc', acc)
        return loss
    def configure_optimizers(self):
        return optim.Adam(self.parameters(), lr=1e-3)

def load_dummy_data(n=200, T=12, F=6, C=4):
    import numpy as np
    X = np.random.randn(n, T, F).astype('float32')
    y = np.random.randint(0, C, size=(n,))
    return X,y

def main(cfg):
    X,y = load_dummy_data(n=500, T=cfg['timesteps'], F=cfg['n_features'], C=cfg['n_classes'])
    ds = TimeSeriesDataset(X,y)
    loader = DataLoader(ds, batch_size=cfg['batch_size'], shuffle=True)
    lit = LitModel(cfg)
    trainer = pl.Trainer(max_epochs=cfg['epochs'], devices=1 if torch.cuda.is_available() else None, accelerator='gpu' if torch.cuda.is_available() else None)
    trainer.fit(lit, loader)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=str, default='config/example.yaml')
    args = parser.parse_args()
    import yaml, os
    cfg = {'timesteps':12, 'n_features':6, 'n_classes':4, 'batch_size':32, 'epochs':5}
    main(cfg)
