# Simple geospatial IO helpers (placeholders)
import rasterio
import numpy as np

def write_geotiff(path, arr, profile):
    with rasterio.open(path, 'w', **profile) as dst:
        dst.write(arr)
