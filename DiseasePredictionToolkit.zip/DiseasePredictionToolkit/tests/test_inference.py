from joblib import load
import pandas as pd

def test_model_load_and_predict():
    clf = load("models/random_forest.joblib")
    pre = load("models/preprocessor.joblib")
    df = pd.read_csv("data/raw/breast_cancer_wisconsin.csv").drop(columns=["label"])
    Xp = pre.transform(df)
    preds = clf.predict(Xp)
    assert len(preds) == len(df)
