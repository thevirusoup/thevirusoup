Create a simple Folium map to visualize predictions:
Example:

import folium
m = folium.Map(location=[26.9, 75.8], zoom_start=6)
folium.TileLayer('Stamen Terrain').add_to(m)
# Add GeoJson layer for predictions
m.save('map.html')
